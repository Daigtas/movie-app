import MovieSection from './MovieSection';
export default MovieSection;
